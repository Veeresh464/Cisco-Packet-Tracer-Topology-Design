#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <dirent.h>

#define PORT 8080
#define BUFFER_SIZE 1024
#define UPLOAD_DIR "server_files/"

// Function to handle each client
void *handle_client(void *client_socket) {
    int sock = *(int *)client_socket;
    char buffer[BUFFER_SIZE];
    char file_path[BUFFER_SIZE];
    FILE *file;

    while (1) {
        // Receive client request
        int bytes_received = recv(sock, buffer, BUFFER_SIZE, 0);
        if (bytes_received <= 0) {
            printf("Client disconnected\n");
            break;
        }
        buffer[bytes_received] = '\0';

        if (strcmp(buffer, "UPLOAD") == 0) {
            // Step 2: Receive the file name
            bytes_received = recv(sock, buffer, BUFFER_SIZE, 0);
            if (bytes_received <= 0) {
                printf("Error receiving file name\n");
                break;
            }
            buffer[bytes_received] = '\0'; // Null-terminate the file name
            snprintf(file_path, sizeof(file_path), "%s%s", UPLOAD_DIR, buffer);

            // Acknowledge the file name reception
            send(sock, "ACK", strlen("ACK"), 0);
            printf("Received file name: %s\n", buffer);

            // Step 3: Open the file for writing
            file = fopen(file_path, "wb");
            if (!file) {
                perror("File open failed");
                break;
            }

            // Step 4: Receive the file content
            printf("Waiting for file content...\n");
            while ((bytes_received = recv(sock, buffer, BUFFER_SIZE, 0)) > 0) {
                if (strcmp(buffer, "END") == 0) {
                    break;
                }
                printf("%s\n", buffer);
                fwrite(buffer, 1, bytes_received, file); // Write received data to the file
                memset(buffer, 0, BUFFER_SIZE);//clear buffer
            }

            printf("File uploaded successfully\n");
            fclose(file);
        }

        if (strcmp(buffer, "DOWNLOAD") == 0) {
            // Download file
            recv(sock, buffer, BUFFER_SIZE, 0);
            snprintf(file_path, sizeof(file_path), "%s%s", UPLOAD_DIR, buffer);
            file = fopen(file_path, "rb");
            if (!file) {
                perror("File not found");
                send(sock, "ERROR", strlen("ERROR"), 0);
                continue;
            }
            printf("Sending file: %s\n", file_path);
            while ((bytes_received = fread(buffer, 1, BUFFER_SIZE, file)) > 0) {
                send(sock, buffer, bytes_received, 0);
            }
            fclose(file);
            // Send "END" signal to mark file transfer completion
            send(sock, "END", strlen("END"), 0);
            printf("File sent successfully\n");
        }


        else if (strcmp(buffer, "LIST") == 0) {
            // List files
            DIR *dir;
            struct dirent *entry;
            dir = opendir(UPLOAD_DIR);
            if (dir == NULL) {
                perror("Directory open failed");
                break;
            }
            while ((entry = readdir(dir)) != NULL) {
                if (entry->d_type == DT_REG) {
                    send(sock, entry->d_name, strlen(entry->d_name), 0);
                    send(sock, "\n", 1, 0);
                }
            }
            closedir(dir);
            send(sock, "END", strlen("END"), 0);
        }

        else if (strcmp(buffer, "EXIT") == 0) {
            break;
        }
    }

    close(sock);
    free(client_socket);
    return NULL;
}

int main() {
    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);

    // Create upload directory if it doesn't exist
    mkdir(UPLOAD_DIR, 0777);

    // Create server socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket == -1) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Configure server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    // Bind socket
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1) {
        perror("Bind failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    // Listen for connections
    if (listen(server_socket, 5) == -1) {
        perror("Listen failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }
    printf("Server is listening on port %d\n", PORT);

    while (1) {
        // Accept a client connection
        client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &addr_len);
        if (client_socket == -1) {
            perror("Accept failed");
            continue;
        }
        printf("Client connected\n");

        // Create a thread for the client
        pthread_t thread_id;
        int *new_sock = malloc(sizeof(int));
        *new_sock = client_socket;
        pthread_create(&thread_id, NULL, handle_client, new_sock);
        pthread_detach(thread_id);
    }

    close(server_socket);
    return 0;
}
