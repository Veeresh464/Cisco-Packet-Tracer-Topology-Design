#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 1024

void display_menu();
void handle_server_response(int socket);

int main() {
    int client_socket;
    struct sockaddr_in server_addr;
    char buffer[BUFFER_SIZE];

    // Create socket
    client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (client_socket < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // Connect to server
    if (connect(client_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection to server failed");
        close(client_socket);
        exit(EXIT_FAILURE);
    }

    printf("Connected to the server.\n\n");

    while (1) {
        display_menu();
        printf("Enter your choice: ");
        fgets(buffer, BUFFER_SIZE, stdin);
        buffer[strcspn(buffer, "\n")] = 0; // Remove newline character

        if (strcmp(buffer, "EXIT") == 0) {
            send(client_socket, buffer, strlen(buffer), 0);
            printf("Disconnected from the server.\n");
            break;
        }

        send(client_socket, buffer, strlen(buffer), 0);
        handle_server_response(client_socket);
    }

    close(client_socket);
    return 0;
}

void display_menu() {
    printf("\n=== Banking Application Menu ===\n");
    printf("1. BALANCE - Check account balance\n");
    printf("2. HISTORY - View transaction history\n");
    printf("3. DEPOSIT <amount> - Deposit money\n");
    printf("4. WITHDRAW <amount> - Withdraw money\n");
    printf("5. EXIT - Disconnect from the server\n");
    printf("=================================\n");
}

void handle_server_response(int socket) {
    char response[BUFFER_SIZE];
    int bytes_received = recv(socket, response, BUFFER_SIZE, 0);

    if (bytes_received > 0) {
        response[bytes_received] = '\0';
        printf("Server response: %s\n", response);
    } else {
        printf("Failed to receive response from server.\n");
    }
}
