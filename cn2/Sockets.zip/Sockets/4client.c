#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <unistd.h>

#define PORT 8080
#define BUFSIZE 1024

int main() {
    int sockfd;
    struct sockaddr_in server_addr;
    char buffer[BUFSIZE], ip1[BUFSIZE], ip2[BUFSIZE], subnet_mask[BUFSIZE];

    // Create socket
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Configure server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    while (1) {
        // Get input from the user
        printf("Enter IP1: ");
        scanf("%s", ip1);
        printf("Enter IP2: ");
        scanf("%s", ip2);
        printf("Enter Subnet Mask: ");
        scanf("%s", subnet_mask);

        // Exit condition
        if (strcmp(ip1, "exit") == 0 || strcmp(ip2, "exit") == 0 || strcmp(subnet_mask, "exit") == 0) {
            printf("Exiting...\n");
            break;
        }

        // Send data to the server
        sprintf(buffer, "%s %s %s", ip1, ip2, subnet_mask);
        sendto(sockfd, buffer, strlen(buffer), 0, (const struct sockaddr *)&server_addr, sizeof(server_addr));

        // Receive and print the response
        int n = recvfrom(sockfd, buffer, BUFSIZE, 0, NULL, NULL);
        buffer[n] = '\0';
        printf("Server Response:\n%s\n", buffer);
    }

    close(sockfd);
    return 0;
}

