#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFSIZE 1024

int main() {
    int sock;
    struct sockaddr_in server_addr;
    char buffer[BUFSIZE];
    char message[BUFSIZE];

    // Create the client socket
    if ((sock = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Configure the server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    if (inet_pton(AF_INET, "127.0.0.1", &server_addr.sin_addr) <= 0) {
        perror("Invalid address");
        close(sock);
        exit(EXIT_FAILURE);
    }

    // Connect to the server
    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");
        close(sock);
        exit(EXIT_FAILURE);
    }

    printf("Connected to the server. Type messages to send:\n");

    while (1) {
        // Get input from the user
        printf("You: ");
        fgets(message, BUFSIZE, stdin);
        message[strcspn(message, "\n")] = '\0'; // Remove newline character

        // Send the message to the server
        send(sock, message, strlen(message), 0);

        // Exit condition
        if (strcmp(message, "exit") == 0) {
            printf("Disconnected from the server.\n");
            break;
        }

        // Receive the echoed message from the server
        int bytes_received = recv(sock, buffer, BUFSIZE, 0);
        if (bytes_received > 0) {
            buffer[bytes_received] = '\0';
            printf("Server: %s\n", buffer);
        } else {
            perror("recv failed");
            break;
        }
    }

    close(sock);
    return 0;
}

