#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <arpa/inet.h>
#include <unistd.h>

#define PORT 8080
#define BUFSIZE 1024

// Function to determine the class of an IPv4 address
char get_ip_class(struct in_addr ip) {
    unsigned char first_octet = (unsigned char)(ip.s_addr >> 24);
    if (first_octet <= 127) return 'A';
    else if (first_octet <= 191) return 'B';
    else if (first_octet <= 223) return 'C';
    else if (first_octet <= 239) return 'D';
    return 'E';
}

// Check if IPs are on the same network
int check_same_network(const char *ip1, const char *ip2, const char *subnet_mask) {
    struct in_addr addr1, addr2, mask;
    inet_pton(AF_INET, ip1, &addr1);
    inet_pton(AF_INET, ip2, &addr2);
    inet_pton(AF_INET, subnet_mask, &mask);
    return (addr1.s_addr & mask.s_addr) == (addr2.s_addr & mask.s_addr);
}

// Determine if the IP is IPv4 or IPv6
const char *check_ip_version(const char *ip) {
    struct sockaddr_in ipv4;
    struct sockaddr_in6 ipv6;
    if (inet_pton(AF_INET, ip, &ipv4.sin_addr)) return "IPv4";
    else if (inet_pton(AF_INET6, ip, &ipv6.sin6_addr)) return "IPv6";
    return "Invalid IP";
}

int main() {
    int sockfd;
    struct sockaddr_in server_addr, client_addr;
    char buffer[BUFSIZE];
    socklen_t addr_len = sizeof(client_addr);

    // Create socket
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Bind the socket
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);
    if (bind(sockfd, (const struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    printf("Server is running on port %d\n", PORT);

    while (1) {
        // Receive IP addresses and subnet mask
        recvfrom(sockfd, buffer, BUFSIZE, 0, (struct sockaddr *)&client_addr, &addr_len);
        char ip1[BUFSIZE], ip2[BUFSIZE], subnet_mask[BUFSIZE];
        sscanf(buffer, "%s %s %s", ip1, ip2, subnet_mask);

        // Check IP version
        const char *version1 = check_ip_version(ip1);
        const char *version2 = check_ip_version(ip2);

        // Check if they are IPv4 and on the same network
        char result[BUFSIZE];
        if (strcmp(version1, "IPv4") == 0 && strcmp(version2, "IPv4") == 0) {
            int same_network = check_same_network(ip1, ip2, subnet_mask);
            struct in_addr addr1;
            inet_pton(AF_INET, ip1, &addr1);
            char class1 = get_ip_class(addr1);

            struct in_addr addr2;
            inet_pton(AF_INET, ip2, &addr2);
            char class2 = get_ip_class(addr2);

            sprintf(result, "IP1: %s, Class: %c, Version: %s\nIP2: %s, Class: %c, Version: %s\nSame Network: %s",
                    ip1, class1, version1, ip2, class2, version2, same_network ? "Yes" : "No");
        } else {
            sprintf(result, "IP1: %s, Version: %s\nIP2: %s, Version: %s\nOnly IPv4 comparison is supported for networks.",
                    ip1, version1, ip2, version2);
        }

        // Send the result back to the client
        sendto(sockfd, result, strlen(result), 0, (const struct sockaddr *)&client_addr, addr_len);
    }

    close(sockfd);
    return 0;
}

