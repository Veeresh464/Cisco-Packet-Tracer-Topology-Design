#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 1024

void upload_file(int sock) {
    char file_name[BUFFER_SIZE];
    char buffer[BUFFER_SIZE];
    FILE *file;
    int bytes_received;

    printf("Enter file path to upload: ");
    scanf("%s", file_name);
    file = fopen(file_name, "rb");
    if (!file) {
        perror("File open failed");
        return;
    }

    // Step 1: Send the "UPLOAD" command to the server
    send(sock, "UPLOAD", strlen("UPLOAD"), 0);

    // Step 2: Send the file name to the server
    send(sock, file_name, strlen(file_name), 0);
    printf("Sent file name: %s\n", file_name);

    // Step 3: Wait for the server's acknowledgment
    bytes_received = recv(sock, buffer, BUFFER_SIZE, 0);
    buffer[bytes_received] = '\0'; // Null-terminate the received message
    if (strcmp(buffer, "ACK") == 0) {
        printf("Server is ready to receive the file content\n");

        // Step 4: Send the file content in chunks
        size_t bytes_read;
        while ((bytes_read = fread(buffer, 1, BUFFER_SIZE, file)) > 0) {
            send(sock, buffer, bytes_read, 0);  // Send file data to the server
        }

        // Send "END" to indicate that the file transfer is complete
        send(sock, "END", strlen("END"), 0);

        printf("File uploaded successfully\n");
    } else {
        printf("Server did not acknowledge the file name\n");
    }

    fclose(file);
}


void download_file(int sock) {
    char file_name[BUFFER_SIZE];
    char buffer[BUFFER_SIZE];
    FILE *file;

    printf("Enter file name to download: ");
    scanf("%s", file_name);

    send(sock, "DOWNLOAD", strlen("DOWNLOAD"), 0);
    send(sock, file_name, strlen(file_name), 0);

    file = fopen(file_name, "wb");
    if (!file) {
        perror("File creation failed");
        return;
    }

    while (1) {
        int bytes_received = recv(sock, buffer, BUFFER_SIZE, 0);
        if (bytes_received <= 0) {
            perror("File receive failed");
            break;
        }

        // Check for the "END" signal
        buffer[bytes_received] = '\0';
        if (strcmp(buffer, "END") == 0) {
            break;
        }

        fwrite(buffer, 1, bytes_received, file);
    }
    fclose(file);
    printf("File downloaded successfully\n");
}


void list_files(int sock) {
    char buffer[BUFFER_SIZE];
    send(sock, "LIST", strlen("LIST"), 0);

    while (1) {
        int bytes_received = recv(sock, buffer, BUFFER_SIZE, 0);
        buffer[bytes_received] = '\0';
        if (strcmp(buffer, "END") == 0) break;
        printf("%s", buffer);
    }
    printf("\n");
}

int main() {
    int sock;
    struct sockaddr_in server_addr;

    // Create socket
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Configure server address
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &server_addr.sin_addr);

    // Connect to server
    if (connect(sock, (struct sockaddr *)&server_addr, sizeof(server_addr)) == -1) {
        perror("Connection failed");
        close(sock);
        exit(EXIT_FAILURE);
    }

    printf("Connected to the server\n");

    while (1) {
        int choice;
        printf("\nMenu:\n1. Upload File\n2. Download File\n3. List Files\n4. Exit\nEnter your choice: ");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                upload_file(sock);
                break;
            case 2:
                download_file(sock);
                break;
            case 3:
                list_files(sock);
                break;
            case 4:
                send(sock, "EXIT", strlen("EXIT"), 0);
                close(sock);
                exit(0);
            default:
                printf("Invalid choice. Try again.\n");
        }
    }

    return 0;
}
