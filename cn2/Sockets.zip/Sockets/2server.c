#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 1024
#define MAX_CLIENTS 10

typedef struct {
    int account_balance;
    char transaction_history[BUFFER_SIZE];
} Account;

Account account = {1000, "Initial balance: 1000\n"};
pthread_mutex_t account_mutex;

void *handle_client(void *client_socket_ptr);
void process_command(int client_socket, char *command);

int main() {
    int server_socket, client_socket;
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);
    pthread_t thread_id;

    pthread_mutex_init(&account_mutex, NULL);

    // Create socket
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY;

    // Bind socket
    if (bind(server_socket, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Socket bind failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    // Listen for connections
    if (listen(server_socket, MAX_CLIENTS) < 0) {
        perror("Socket listen failed");
        close(server_socket);
        exit(EXIT_FAILURE);
    }

    printf("Server is listening on port %d\n", PORT);

    while (1) {
        client_socket = accept(server_socket, (struct sockaddr *)&client_addr, &addr_len);
        if (client_socket < 0) {
            perror("Client connection failed");
            continue;
        }

        printf("New client connected\n");

        if (pthread_create(&thread_id, NULL, handle_client, (void *)&client_socket) != 0) {
            perror("Thread creation failed");
            close(client_socket);
        }
    }

    close(server_socket);
    pthread_mutex_destroy(&account_mutex);
    return 0;
}

void *handle_client(void *client_socket_ptr) {
    int client_socket = *(int *)client_socket_ptr;
    char buffer[BUFFER_SIZE];
    int bytes_received;

    while ((bytes_received = recv(client_socket, buffer, BUFFER_SIZE, 0)) > 0) {
        buffer[bytes_received] = '\0';
        process_command(client_socket, buffer);
    }

    printf("Client disconnected\n");
    close(client_socket);
    pthread_exit(NULL);
}

void process_command(int client_socket, char *command) {
    char response[BUFFER_SIZE];

    if (strncmp(command, "BALANCE", 7) == 0) {
        pthread_mutex_lock(&account_mutex);
        snprintf(response, BUFFER_SIZE, "Account balance: %d\n", account.account_balance);
        pthread_mutex_unlock(&account_mutex);
    } else if (strncmp(command, "HISTORY", 7) == 0) {
        pthread_mutex_lock(&account_mutex);
        snprintf(response, BUFFER_SIZE, "Transaction history:\n%s", account.transaction_history);
        pthread_mutex_unlock(&account_mutex);
    } else if (strncmp(command, "DEPOSIT", 7) == 0) {
        int amount = atoi(command + 8);
        if (amount > 0) {
            pthread_mutex_lock(&account_mutex);
            account.account_balance += amount;
            snprintf(account.transaction_history + strlen(account.transaction_history), BUFFER_SIZE - strlen(account.transaction_history), "Deposited: %d\n", amount);
            snprintf(response, BUFFER_SIZE, "Deposit successful. New balance: %d\n", account.account_balance);
            pthread_mutex_unlock(&account_mutex);
        } else {
            snprintf(response, BUFFER_SIZE, "Invalid deposit amount\n");
        }
    } else if (strncmp(command, "WITHDRAW", 8) == 0) {
        int amount = atoi(command + 9);
        pthread_mutex_lock(&account_mutex);
        if (amount > 0 && amount <= account.account_balance) {
            account.account_balance -= amount;
            snprintf(account.transaction_history + strlen(account.transaction_history), BUFFER_SIZE - strlen(account.transaction_history), "Withdrawn: %d\n", amount);
            snprintf(response, BUFFER_SIZE, "Withdrawal successful. New balance: %d\n", account.account_balance);
        } else if (amount > account.account_balance) {
            snprintf(response, BUFFER_SIZE, "Insufficient balance\n");
        } else {
            snprintf(response, BUFFER_SIZE, "Invalid withdrawal amount\n");
        }
        pthread_mutex_unlock(&account_mutex);
    } else {
        snprintf(response, BUFFER_SIZE, "Invalid command\n");
    }

    send(client_socket, response, strlen(response), 0);
}

